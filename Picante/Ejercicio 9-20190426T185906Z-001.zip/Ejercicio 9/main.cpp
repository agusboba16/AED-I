# include "ventana.h"
#include "login.h"
#include <QWidget>
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc,argv);
    Login login;
    Mapa mapa;

    login.resize(250,120);
    login.setWindowTitle("Login");
    mapa.setWindowTitle("Ventana");
    login.show();

    return a.exec();
}
