#ifndef VENTANA
#define VENTANA

#include <QWidget>
#include <QImage>

class Mapa : public QWidget{
    Q_OBJECT

public:
    Mapa(QWidget * parent = 0);

private:
    QImage *img;
    void paintEvent(QPaintEvent *);

};
#endif

