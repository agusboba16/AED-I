#include "login.h"
#include "ventana.h"

Login::Login()
{
    lUsuario = new QLabel("Usuario");
    lClave = new QLabel("Clave");

    leUsuario = new QLineEdit;
    leClave = new QLineEdit;
    leClave->setEchoMode(QLineEdit::Password);
    cont = 0;

    pbAceptar = new QPushButton("Ingresar");

    layout = new QGridLayout;
    layout->addWidget(lUsuario,1,0,1,2);
    layout->addWidget(lClave,3,0,1,2);
    layout->addWidget(leUsuario,1, 2, 1,3);
    layout->addWidget(leClave, 3, 2, 1, 3);
    layout->addWidget(pbAceptar,5,5,1,2);


    this->setLayout(layout);


    connect(leClave, SIGNAL(returnPressed()), this, SLOT(slot_aceptar()));
    connect(pbAceptar, SIGNAL(clicked()), this, SLOT(slot_aceptar()));
}

void Login::slot_aceptar()
{
    Mapa *mapa = new Mapa;

    if (leUsuario->text() == "admin" && leClave->text() == "1234")
    {
        this->close();
        mapa->show();
    }
    else
    {

      this->close();
    }
}
