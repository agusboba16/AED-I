#include "ventana.h"
#include <QPainter>
#include <QColor>
#include <QBrush>
#include <QDir>
#include <QDebug>
#include <QImage>

Mapa::Mapa(QWidget *parent) : QWidget(parent){

     img = new QImage("F:/Materias/POO 2018/Ejercicios/Ejercicio 9/imagen/89b020b5abc56798d5cfd66e2077b799.jpg");
}
void Mapa::paintEvent(QPaintEvent *){

    QPainter pincel(this);
/*
    pincel.drawLine(0,0,this->width(),this->height());
    pincel.drawLine(0,0,this->width(),this->height());
    pincel.drawRect(100,100,200,200);

    pincel.fillRect(500,500,300,300,Qt::red);
    pincel.fillRect(100,200,300,300,Qt::green);
*/
    qDebug()<<QDir::currentPath();
    pincel.drawImage(this->width() / 2 - img->width() / 2,this->height() / 2 - img->height() / 2,*img);
    *img = img->scaled(this->width()/5,this->height()/4);

}
