#include "admindb.h"


AdminDB::AdminDB()
{
    db = QSqlDatabase::addDatabase("QSQLITE");
}

AdminDB::~AdminDB()
{

}

bool AdminDB::conectar(QString nombreBase)
{
    db.setDatabaseName(nombreBase);
    if(db.open())
    {
        return true;
    }
    return false;
}

QVector <QString> AdminDB::select(QString comando)
{
    QVector<QString> registros;
    QSqlRecord rec= db.record("usuarios");
    QSqlQuery query= db.exec(comando);
    while(query.next())
    {
        QString campos;
        for (int i = 0; i < rec.count(); ++i)
        {
            campos.append(query.value(i).toString()+"  ");
        }
        registros.append( campos );

    }
    return registros;
}
