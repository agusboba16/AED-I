#include "widget.h"
#include "ui_widget.h"


Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    d=new AdminDB;

    ui->setupUi(this);
    Conectar=new QPushButton("Conectar");
    Nombre = new QLabel("Nombre: ");
    Direccion = new QLineEdit("F:/Materias/POO 2018/Ejercicios/Ejercicio 10/test");
    Tabla= new QTextEdit;
    Layout = new QGridLayout;

    Layout->addWidget(Nombre,0,0,1,1,Qt::AlignTop);
    Layout->addWidget(Direccion,0,1,1,1,Qt::AlignTop);
    Layout->addWidget(Conectar,0,2,1,1,Qt::AlignTop);
    Layout->addWidget(Tabla,1,0,1,2);

    this->setLayout(Layout);
    connect(Conectar,SIGNAL(pressed()),this,SLOT(conetame_esta()));

}

Widget::~Widget()
{
    delete ui;
}

void Widget::conetame_esta()
{
    Tabla->clear();
    QVector <QString> v;
    if(d->conectar(Direccion->text()))
    {
        v=d->select("select * from usuarios");
    }
    for (int i = 0; i < v.length(); ++i)
    {
        QString list = v.at(i);
        Tabla->append(list);
    }
}
