#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QPushButton>
#include <QGridLayout>
#include <QLabel>
#include <QLineEdit>
#include <QTextEdit>
#include <QString>
#include <QStringList>
#include <admindb.h>


namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

private:
    Ui::Widget *ui;

    AdminDB *d;
    QPushButton *Conectar;
    QLabel *Nombre;
    QLineEdit *Direccion;
    QGridLayout *Layout;
    QTextEdit *Tabla;

private slots:
    void conetame_esta();
};

#endif // WIDGET_H
