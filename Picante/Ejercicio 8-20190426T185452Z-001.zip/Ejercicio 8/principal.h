#ifndef PRINCIPAL_H
#define PRINCIPAL_H

#include <QWidget>
#include <QPushButton>
#include <QLineEdit>
#include <QGridLayout>
#include <QSlider>
#include <QLabel>
#include "mapa.h"

class Principal:public QWidget{
    Q_OBJECT
public:
    explicit Principal(QWidget *parent = 0);
    ~Principal();
private:
    QPushButton *pbBuscar;
    QLineEdit * leDomicilio;
    Mapa *mapa;
    QGridLayout *layout;
    QSlider *slZoom;



private slots:
    void slot_buscar();

};


#endif // PRINCIPAL_H

