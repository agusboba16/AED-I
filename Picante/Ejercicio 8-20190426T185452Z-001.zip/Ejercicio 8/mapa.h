#ifndef MAPA_H
#define MAPA_H

#include <QWidget>
#include <QImage>
#include <QNetworkAccessManager>
#include <QNetworkReply>

class Mapa:public QWidget{
    Q_OBJECT
public:
    explicit Mapa(QWidget * parent = 0);

    //Metodo que nos permite buscar domicilio en la imagen
    //Busca el domicilio: EJ Guayama 1990.
    void buscarDomicilio(QString domicilio,int zoom);
protected:
    void paintEvent(QPaintEvent*);
private:
    QImage im;
    QNetworkAccessManager *manager;
private slots:
    void descargaFinalizada(QNetworkReply * reply);

};

#endif // MAPA_H

