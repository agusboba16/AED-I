#include <QPainter>
#include <QString>
#include <QUrl>
#include "mapa.h"


Mapa::Mapa(QWidget *parent):QWidget(parent),
                manager(new QNetworkAccessManager(this)){
    connect(manager,SIGNAL(finished(QNetworkReply*)),
            this,SLOT(descargaFinalizada(QNetworkReply*)));

}

void Mapa::buscarDomicilio(QString domicilio,int zoom){
    QString sUrl = "http://maps.googleapis.com/maps/api/staticmap?center=" + domicilio + "cordoba&zoom=" + zoom +"&size=500x300&maptype=roadmap&sensor=false";
    QUrl url(sUrl);

    QNetworkRequest req(url);
    manager->get(req);

}

void Mapa::paintEvent(QPaintEvent *){
    QPainter painter(this);
    painter.drawImage(0,0,im.scaled(this->width(),(this->height())));

    //no modifica el objeto original si no que devuelve un objeto QImage nuevo
}

void Mapa::descargaFinalizada(QNetworkReply *reply){

    im = QImage::fromData(reply->readAll());
    this->repaint();
}

