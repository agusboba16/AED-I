#include <QApplication>
#include "principal.h"
#include "mapa.h"


int main(int argc, char** argv){
    QApplication a(argc,argv);

    Principal principal;
    principal.show();
    principal.resize(400,400);



    return a.exec();
}
