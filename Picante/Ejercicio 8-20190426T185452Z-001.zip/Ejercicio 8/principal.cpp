#include "principal.h"
#include "mapa.h"

Principal::Principal(QWidget *parent):QWidget(parent),pbBuscar(new QPushButton("Buscar")),
                    leDomicilio(new QLineEdit(this)),mapa(new Mapa(this)),layout (new QGridLayout),slZoom(new QSlider){

    slZoom->setMaximum(99);
    slZoom->setMinimum(01);
    layout->addWidget(leDomicilio,0,0,1,5);
    layout->addWidget(pbBuscar,0,5);
    layout->addWidget(mapa,1,0,12,6);
    layout->addWidget(slZoom,1,6,1,6);

    this->setLayout(layout);
    connect(pbBuscar,SIGNAL(pressed() ),this,SLOT(slot_buscar() ) );
    connect(slZoom,SIGNAL(sliderMoved(int) ),this,SLOT(slot_buscar() ) );
}


void Principal::slot_buscar(){

    mapa->buscarDomicilio(leDomicilio->text(),slZoom->value());

}

Principal::~Principal(){

    delete pbBuscar;
    delete layout;

}


