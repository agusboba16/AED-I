#ifndef PRINCIPAL_H
#define PRINCIPAL_H

#include <QWidget>
#include<QSqlDatabase>
#include<QSqlQuery>
#include<QSqlRecord>
#include<QNetworkAccessManager>
#include<QNetworkReply>
#include<QDebug>
#include<QList>
#include<QImage>
#include<QPainter>
#include<QPaintEvent>
#include<QPushButton>

namespace Ui {
class Principal;
}

class Principal : public QWidget
{
    Q_OBJECT

public:
    explicit Principal(QWidget *parent = 0);
    void url_imagen(QString url);
    ~Principal();

private:
    Ui::Principal *ui;
    QImage im;
    QNetworkAccessManager *manager;
    QSqlDatabase admin;
    QList<QImage> lista;
    int index;

private:
    void cargarImagenes();
    void paintEvent(QPaintEvent *);

public slots:
    void slot_descargaFinalizada(QNetworkReply *reply);
    void slot_forwardPressed();
    void slot_backPressed();

};

#endif // PRINCIPAL_H
