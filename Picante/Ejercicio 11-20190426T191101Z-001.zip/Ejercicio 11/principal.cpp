#include "principal.h"
#include "ui_principal.h"

Principal::Principal(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Principal),
    manager( new QNetworkAccessManager( this ) )
{
    ui->setupUi(this);
    index=0;
    admin = QSqlDatabase::addDatabase("QSQLITE");
    admin.setDatabaseName("../Ejercicio11/imagenes/imagenes.sqlite");
    admin.open();
    cargarImagenes();

    connect(manager,SIGNAL(finished(QNetworkReply*)),this,SLOT(slot_descargaFinalizada(QNetworkReply*)));
    connect(ui->pbVolver,SIGNAL(pressed()),this,SLOT(slot_backPressed()));
    connect(ui->pbSiguiente,SIGNAL(pressed()),this,SLOT(slot_forwardPressed()));
}

Principal::~Principal()
{
    delete ui;
}
void Principal::cargarImagenes(){

QSqlQuery *query = new QSqlQuery(admin);
query->exec("SELECT url FROM imagenes");
QSqlRecord record = query->record();
int i=record.indexOf("url");


while(query->next())
{
    manager->get(QNetworkRequest(QUrl(query->value(i).toString())));
}
}


void Principal::paintEvent(QPaintEvent *){
    QPainter painter(this);

    if(!lista.isEmpty())
    {
        painter.drawImage(40,40,lista.at(index).scaled(this->width()-80,this->height()-80));
    }
}


void Principal::slot_descargaFinalizada(QNetworkReply *reply){
    QImage imagen = QImage::fromData(reply->readAll());
    lista.append(imagen);
    repaint();
}

void Principal::slot_forwardPressed(){
    if(index<lista.size()-1)
    {
        index++;
        repaint();
    }
}

void Principal::slot_backPressed(){
    if(index>0)
    {
        index--;
        repaint();
    }
}
