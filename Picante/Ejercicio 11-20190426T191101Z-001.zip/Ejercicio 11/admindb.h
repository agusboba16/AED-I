#ifndef ADMINDB_H
#define ADMINDB_H

#include <QSqlDatabase>
#include <QObject>
#include <QString>


class AdminDB : public QObject{

    Q_OBJECT

public:
    AdminDB(QObject * parent = 0);
    bool conectar(QString nombreArchivo);
    QString validar(QString url, QString tabla = "imagenes");
    QVector<QStringList> select(QString consulta);

private:
    QSqlDatabase db;

};

#endif // ADMINDB_H
