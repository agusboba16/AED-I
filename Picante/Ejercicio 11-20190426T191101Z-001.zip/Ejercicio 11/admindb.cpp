#include "admindb.h"
#include <QDebug>
#include <QSqlError>
#include <QSqlRecord>
#include <QSqlQuery>

AdminDB::AdminDB(QObject *parent) : QObject(parent){
    db = QSqlDatabase::addDatabase("QSQLITE");
}

bool AdminDB::conectar(QString nombreArchivo){
    db.setDatabaseName(nombreArchivo);
    return db.open();
}

QString AdminDB::validar(QString url, QString tabla){

    if(db.isOpen()){
        QSqlQuery query = db.exec("SELECT id FROM " + tabla + " WHERE url='" + url + "'");

        while(query.next()){
         return query.value(0).toString();

        }
   }
       else return " ";
   return 0;
}

QVector<QStringList> AdminDB::select(QString consulta){
    QVector<QStringList> v;

    QSqlQuery query = db.exec(consulta);

    while(query.next()){

        QSqlRecord qsr = query.record();
        QStringList lista;
        int cantidad = 0;
        while(cantidad < qsr.count()){
              lista << qsr.value(cantidad).toString();
              cantidad++;
        }
        v.append(lista);
    }

    return v;
}

